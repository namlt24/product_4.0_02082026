package com.viettel.bccs.productcatalog.productofferrelation.dto.response;

import java.time.LocalDate;

public record ProductOfferRelationResponse(
        Long productOfferRelationId,
        Long relationTypeId,
        Long mainOfferId,
        Long relationOfferId,
        String status,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime,
        String configPhase,
        String description,
        LocalDate effectDatetime,
        LocalDate expireDatetime
) {
}