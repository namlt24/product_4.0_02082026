package com.viettel.bccs.policy.action.dto.response;

import java.time.LocalDate;

public record ActionResponse(
        String actionCode,
        String name,
        String description,
        String status,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime,
        String type,
        String reasonType
) {
}