package com.viettel.bccs.productcatalog.client;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.viettel.bccs.client.core.BccsHttpClient;
import com.viettel.bccs.productcatalog.client.dto.StandardClientResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class MappingClientImpl implements MappingClient {

    private static final String POLICY_SERVICE = "product-policy-service";

    private final BccsHttpClient bccsHttpClient;
    private final ObjectMapper objectMapper;

    @Override
    public List<String> findSaleServiceCodeByReason(Long reasonId) {
        try {
            var response = bccsHttpClient.get(
                    POLICY_SERVICE,
                    "/v1/mapping/findSaleServiceCodeByReason/{reasonId}",
                    StandardClientResponse.class,
                    reasonId);
            if (response != null && response.getData() != null) {
                return objectMapper.convertValue(response.getData(), new TypeReference<List<String>>() {});
            }
            return null;
        } catch (RuntimeException e) {
            log.error("Error calling findSaleServiceCodeByReason for reasonId={}", reasonId, e);
            return null;
        }
    }
}