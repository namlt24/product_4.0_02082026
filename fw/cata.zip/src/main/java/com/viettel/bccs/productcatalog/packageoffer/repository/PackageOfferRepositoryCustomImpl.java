package com.viettel.bccs.productcatalog.packageoffer.repository;

import com.viettel.bccs.productcatalog.packageoffer.entity.PackageOfferEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Tuple;
import lombok.RequiredArgsConstructor;
import org.hibernate.query.NativeQuery;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class PackageOfferRepositoryCustomImpl implements PackageOfferRepositoryCustom {

    private static final int BATCH_SIZE = 100;
    private final EntityManager entityManager;

    @Override
    public Map<Long, List<PackageOfferEntity>> getPackageOfferByListProdPackTypeIds(List<Long> prodPackTypeIds) {
        if (prodPackTypeIds == null || prodPackTypeIds.isEmpty()) {
            return Map.of();
        }
        Map<Long, List<PackageOfferEntity>> result = new HashMap<>();
        for (int i = 0; i < prodPackTypeIds.size(); i += BATCH_SIZE) {
            List<Long> batch = prodPackTypeIds.subList(i, Math.min(i + BATCH_SIZE, prodPackTypeIds.size()));
            executeQuery(batch, result);
        }
        return result;
    }

    private void executeQuery(List<Long> prodPackTypeIds, Map<Long, List<PackageOfferEntity>> result) {
        StringBuilder inClause = new StringBuilder();
        for (int i = 0; i < prodPackTypeIds.size(); i++) {
            inClause.append(i == 0 ? ":id" + i : ", :id" + i);
        }

        String sql = """
            SELECT a.*
            FROM PACKAGE_OFFER a
            WHERE a.PROD_PACK_TYPE_ID IN (%s)
            """.formatted(inClause);

        NativeQuery<Tuple> query = (NativeQuery<Tuple>) entityManager.createNativeQuery(sql, Tuple.class);
        for (int i = 0; i < prodPackTypeIds.size(); i++) {
            query.setParameter("id" + i, prodPackTypeIds.get(i));
        }

        List<Tuple> rows = query.getResultList();
        for (Tuple row : rows) {
            PackageOfferEntity entity = mapRowToEntity(row);
            result.computeIfAbsent(entity.getProdPackTypeId(), k -> new ArrayList<>()).add(entity);
        }
    }

    private PackageOfferEntity mapRowToEntity(Tuple row) {
        PackageOfferEntity e = new PackageOfferEntity();
        e.setProdPackOfferId(toLong(row.get("PROD_PACK_OFFER_ID", BigDecimal.class)));
        e.setProdPackTypeId(toLong(row.get("PROD_PACK_TYPE_ID", BigDecimal.class)));
        e.setProductOfferingId(toLong(row.get("PRODUCT_OFFERING_ID", BigDecimal.class)));
        e.setProductOfferTypeId(toLong(row.get("PRODUCT_OFFER_TYPE_ID", BigDecimal.class)));
        e.setProductPackageId(toLong(row.get("PRODUCT_PACKAGE_ID", BigDecimal.class)));
        e.setProductOfferPriceId(toLong(row.get("PRODUCT_OFFER_PRICE_ID", BigDecimal.class)));
        e.setOfferCode(row.get("OFFER_CODE", String.class));
        e.setOfferName(row.get("OFFER_NAME", String.class));
        e.setOfferType(row.get("OFFER_TYPE", String.class));
        e.setStatus(row.get("STATUS", String.class));
        e.setPackageCode(row.get("PACKAGE_CODE", String.class));
        e.setPackageName(row.get("PACKAGE_NAME", String.class));
        e.setPrice(toLong(row.get("PRICE", BigDecimal.class)));
        e.setVat(toLong(row.get("VAT", BigDecimal.class)));
        e.setNumOffer(toLong(row.get("NUM_OFFER", BigDecimal.class)));
        e.setOriginalPrice(toLong(row.get("ORIGINAL_PRICE", BigDecimal.class)));
        e.setMinPrice(toLong(row.get("MIN_PRICE", BigDecimal.class)));
        e.setMaxPrice(toLong(row.get("MAX_PRICE", BigDecimal.class)));
        e.setPriceType(row.get("PRICE_TYPE", String.class));
        e.setSupplyMethod(row.get("SUPPLY_METHOD", String.class));
        e.setProvideMethodId(toLong(row.get("PROVIDE_METHOD_ID", BigDecimal.class)));
        e.setSapMaterialNumber(toLong(row.get("SAP_MATERIAL_NUMBER", BigDecimal.class)));
        e.setSapMaterialName(row.get("SAP_MATERIAL_NAME", String.class));
        e.setAccountingModelCode(row.get("ACCOUNTING_MODEL_CODE", String.class));
        e.setAccountingModelName(row.get("ACCOUNTING_MODEL_NAME", String.class));
        e.setCreateDatetime(toDate(row.get("CREATE_DATETIME")));
        e.setEffectDatetime(toDate(row.get("EFFECT_DATETIME")));
        e.setExpireDatetime(toDate(row.get("EXPIRE_DATETIME")));
        e.setUpdateDatetime(toDate(row.get("UPDATE_DATETIME")));
        e.setCreateUser(row.get("CREATE_USER", String.class));
        e.setUpdateUser(row.get("UPDATE_USER", String.class));
        e.setIsMandatory(row.get("IS_MANDATORY", String.class));
        e.setCheckStaffStock(row.get("CHECK_STAFF_STOCK", String.class));
        e.setCheckShopStock(row.get("CHECK_SHOP_STOCK", String.class));
        e.setShopValue(row.get("SHOP_VALUE", String.class));
        e.setUpdateStockId(toLong(row.get("UPDATE_STOCK_ID", BigDecimal.class)));
        e.setUpdateStockValue(row.get("UPDATE_STOCK_VALUE", String.class));
        e.setReasonEffectDate(toDate(row.get("REASON_EFFECT_DATE")));
        e.setReasonExpireDate(toDate(row.get("REASON_EXPIRE_DATE")));
        e.setNewOrSold(row.get("NEW_OR_SOLD", String.class));
        e.setAction(row.get("ACTION", String.class));
        e.setProductTypeName(row.get("PRODUCT_TYPE_NAME", String.class));
        e.setErrorCode(row.get("ERROR_CODE", String.class));
        e.setKeyMes(row.get("KEY_MES", String.class));
        e.setFakeProdPackTypeId(row.get("FAKE_PROD_PACK_TYPE_ID", String.class));
        e.setPledgeTime(row.get("PLEDGE_TIME", String.class));
        e.setPledgeAmount(row.get("PLEDGE_AMOUNT", String.class));
        e.setLstShopCode(row.get("LST_SHOP_CODE", String.class));
        e.setLimitGoods(toLong(row.get("LIMIT_GOODS", BigDecimal.class)));
        e.setProdPackTypeLimitGoods(toLong(row.get("PROD_PACK_TYPE_LIMIT_GOODS", BigDecimal.class)));
        e.setConcatSaleProgram(row.get("CONCAT_SALE_PROGRAM", String.class));
        e.setCheckSerial(toShort(row.get("CHECK_SERIAL", BigDecimal.class)));
        e.setDescription(row.get("DESCRIPTION", String.class));
        e.setDescriptionOffer(row.get("DESCRIPTION_OFFER", String.class));
        e.setReasonCode(row.get("REASON_CODE", String.class));
        e.setReasonName(row.get("REASON_NAME", String.class));
        e.setShowOrHide(row.get("SHOW_OR_HIDE", String.class));
        e.setDistribute(toLong(row.get("DISTRIBUTE", BigDecimal.class)));
        e.setDistributeName(row.get("DISTRIBUTE_NAME", String.class));
        e.setTypeAllocation(row.get("TYPE_ALLOCATION", String.class));
        e.setNumMonthAllocation(row.get("NUM_MONTH_ALLOCATION", String.class));
        e.setProductHierarchy(row.get("PRODUCT_HIERARCHY", String.class));
        return e;
    }

    private Long toLong(BigDecimal value) {
        return value != null ? value.longValue() : null;
    }

    private Short toShort(BigDecimal value) {
        return value != null ? value.shortValue() : null;
    }

    private java.util.Date toDate(Object value) {
        if (value == null) return null;
        if (value instanceof java.util.Date) return (java.util.Date) value;
        if (value instanceof java.sql.Date) return new java.util.Date(((java.sql.Date) value).getTime());
        if (value instanceof java.sql.Timestamp) return new java.util.Date(((java.sql.Timestamp) value).getTime());
        return null;
    }
}