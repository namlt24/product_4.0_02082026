package com.viettel.bccs.organization.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    private static final String SECURITY_SCHEME_NAME = "bearerAuth";

    @Bean
    public OpenAPI bccsOpenApi(
            @Value("${spring.application.name:organization-resource-service}") String applicationName,
            @Value("${bccs.observability.service-version:dev}") String applicationVersion,
            @Value("${bccs.security.jwt.enabled:true}") boolean jwtEnabled) {

        OpenAPI openAPI = new OpenAPI()
                .info(new Info()
                        .title(applicationName + " API")
                        .version(applicationVersion)
                        .description("BCCS service API documentation"));

        if (jwtEnabled) {
            openAPI.addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME_NAME))
                   .components(new Components()
                           .addSecuritySchemes(SECURITY_SCHEME_NAME,
                                   new SecurityScheme()
                                           .name(SECURITY_SCHEME_NAME)
                                           .type(SecurityScheme.Type.HTTP)
                                           .scheme("bearer")
                                           .bearerFormat("JWT")));
        }

        return openAPI;
    }
}
