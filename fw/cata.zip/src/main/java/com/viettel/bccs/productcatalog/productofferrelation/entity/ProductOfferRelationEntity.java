package com.viettel.bccs.productcatalog.productofferrelation.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "PRODUCT_OFFER_RELATION")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductOfferRelationEntity {

    @Id
    @Column(name = "PRODUCT_OFFER_RELATION_ID", precision = 10)
    private Long productOfferRelationId;

    @Column(name = "RELATION_TYPE_ID", precision = 10)
    private Long relationTypeId;

    @Column(name = "MAIN_OFFER_ID", precision = 10)
    private Long mainOfferId;

    @Column(name = "RELATION_OFFER_ID", precision = 10)
    private Long relationOfferId;

    @Column(name = "STATUS", length = 1)
    private String status;

    @Column(name = "CREATE_USER", length = 50)
    private String createUser;

    @Column(name = "CREATE_DATETIME")
    private LocalDate createDatetime;

    @Column(name = "UPDATE_USER", length = 50)
    private String updateUser;

    @Column(name = "UPDATE_DATETIME")
    private LocalDate updateDatetime;

    @Column(name = "CONFIG_PHASE", length = 200)
    private String configPhase;

    @Column(name = "DESCRIPTION", length = 512)
    private String description;

    @Column(name = "EFFECT_DATETIME")
    private LocalDate effectDatetime;

    @Column(name = "EXPIRE_DATETIME")
    private LocalDate expireDatetime;
}