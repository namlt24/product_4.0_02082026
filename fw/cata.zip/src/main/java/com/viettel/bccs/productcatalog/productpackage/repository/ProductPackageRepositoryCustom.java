package com.viettel.bccs.productcatalog.productpackage.repository;

import com.viettel.bccs.productcatalog.productpackage.dto.response.ProductPackageDTO;

import java.util.List;

public interface ProductPackageRepositoryCustom {

    List<ProductPackageDTO> getProductPackageExtra(String code, String productPackageType, boolean isActive, boolean isUpperCode, boolean checkStatus);
}