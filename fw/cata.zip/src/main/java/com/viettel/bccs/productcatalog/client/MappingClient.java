package com.viettel.bccs.productcatalog.client;

import java.util.List;

/**
 * Client gọi sang product-policy-service để truy vấn thông tin mapping dịch vụ bán hàng.
 */
public interface MappingClient {

    /**
     * Tìm danh sách mã dịch vụ bán hàng (SALE_SERVICE_CODE) theo lý do (REASON_ID).
     * Gọi sang product-policy-service: GET /product-policy-service/v1/mapping/findSaleServiceCodeByReason
     *
     * @param reasonId id lý do
     * @return danh sách mã dịch vụ bán hàng, hoặc null nếu không có kết quả
     */
    List<String> findSaleServiceCodeByReason(Long reasonId);
}