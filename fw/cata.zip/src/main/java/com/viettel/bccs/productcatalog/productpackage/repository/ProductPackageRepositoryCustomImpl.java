package com.viettel.bccs.productcatalog.productpackage.repository;

import com.viettel.bccs.productcatalog.productpackage.dto.response.ProductPackageDTO;
import com.viettel.bccs.productcatalog.utils.DataUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class ProductPackageRepositoryCustomImpl implements ProductPackageRepositoryCustom {

    private final EntityManager entityManager;

    @Override
    @SuppressWarnings("unchecked")
    public List<ProductPackageDTO> getProductPackageExtra(String code, String productPackageType, boolean isActive, boolean isUpperCode, boolean checkStatus) {
        StringBuilder sql = new StringBuilder();
        sql.append("""
                SELECT prp.PRODUCT_PACKAGE_ID,
                       prp.NAME,
                       prp.CODE,
                       prp.DESCRIPTION,
                       prp.STATUS,
                       prp.EFFECT_DATETIME,
                       prp.EXPIRE_DATETIME,
                       prp.CREATE_USER,
                       prp.CREATE_DATETIME,
                       prp.UPDATE_USER,
                       prp.UPDATE_DATETIME,
                       prp.VERSION,
                       prp.TYPE,
                       prp.ACCOUNTING_ID,
                       prp.FEE_TYPE,
                       prp.TELECOM_SERVICE_ID,
                       prp.UNIT,
                       prp.NOTE,
                       prp.AREA_GROUP_ID,
                       prp.OWNER_SHOP_ID,
                       prp.SAP_MATERIAL_NUMBER,
                       prp.IT_TELCOL,
                       (SELECT pcu.SPECIFIC_VALUE
                        FROM BCCS_PRODUCT.PRODUCT_PACKAGE_CHAR_USE pcu
                        WHERE pcu.PRODUCT_SPEC_CHAR_ID IN (
                            SELECT psc.PRODUCT_SPEC_CHAR_ID
                            FROM BCCS_PRODUCT.PRODUCT_SPEC_CHAR psc
                            WHERE psc.CODE = 'GENERALNAME'
                        )
                          AND pcu.PRODUCT_PACKAGE_ID = prp.PRODUCT_PACKAGE_ID
                          AND pcu.STATUS = 1
                          AND ROWNUM = 1) AS defaultName
                FROM BCCS_PRODUCT.PRODUCT_PACKAGE prp
                WHERE 1 = 1
                """);

        if (checkStatus) {
            sql.append(" AND prp.STATUS = :p_status");
        }
        if (isActive) {
            sql.append(" AND (prp.EFFECT_DATETIME IS NULL OR prp.EFFECT_DATETIME < SYSDATE) AND (prp.EXPIRE_DATETIME IS NULL OR prp.EXPIRE_DATETIME >= TRUNC(SYSDATE))");
        }
        if (isUpperCode) {
            sql.append(" AND UPPER(prp.CODE) = UPPER(:p_code)");
        } else {
            sql.append(" AND prp.CODE = :p_code");
        }
        if (!org.springframework.util.StringUtils.isEmpty(productPackageType)) {
            sql.append(" AND prp.TYPE = :p_type");
        }

        sql.append(" ORDER BY prp.PRODUCT_PACKAGE_ID");

        Query query = entityManager.createNativeQuery(sql.toString());

        if (checkStatus) {
            query.setParameter("p_status", "1");
        }
        if (!org.springframework.util.StringUtils.isEmpty(code)) {
            query.setParameter("p_code", code);
        }
        if (!org.springframework.util.StringUtils.isEmpty(productPackageType)) {
            query.setParameter("p_type", productPackageType);
        }

        List<Object[]> results = query.getResultList();
        if (results.isEmpty()) {
            return Collections.emptyList();
        }
        return results.stream().map(this::mapRowToDTO).toList();
    }

    private ProductPackageDTO mapRowToDTO(Object[] row) {
        return ProductPackageDTO.builder()
                .productPackageId(DataUtil.safeToLong(row[0], null))
                .name(DataUtil.safeToString(row[1], null))
                .code(DataUtil.safeToString(row[2], null))
                .description(DataUtil.safeToString(row[3], null))
                .status(DataUtil.safeToString(row[4], null))
                .effectDatetime(DataUtil.toDate(row[5]))
                .expireDatetime(DataUtil.toDate(row[6]))
                .createUser(DataUtil.safeToString(row[7], null))
                .createDatetime(DataUtil.toDate(row[8]))
                .updateUser(DataUtil.safeToString(row[9], null))
                .updateDatetime(DataUtil.toDate(row[10]))
                .version(DataUtil.safeToString(row[11], null))
                .type(DataUtil.safeToString(row[12], null))
                .accountingId(DataUtil.safeToLong(row[13], null))
                .feeType(DataUtil.safeToString(row[14], null))
                .telecomServiceId(DataUtil.safeToLong(row[15], null))
                .unit(DataUtil.safeToString(row[16], null))
                .note(DataUtil.safeToString(row[17], null))
                .areaGroupId(DataUtil.safeToLong(row[18], null))
                .ownerShopId(DataUtil.safeToLong(row[19], null))
                .sapMaterialNumber(DataUtil.safeToLong(row[20], null))
                .itTelcol(DataUtil.safeToString(row[21], null))
                .defaultName(DataUtil.safeToString(row[22], null))
                .build();
    }
}