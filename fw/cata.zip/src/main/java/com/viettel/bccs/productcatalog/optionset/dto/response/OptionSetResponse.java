package com.viettel.bccs.productcatalog.optionset.dto.response;

import java.time.LocalDate;

public record OptionSetResponse(
        Long optionSetId,
        String code,
        String name,
        String status,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime,
        String description
) {
}