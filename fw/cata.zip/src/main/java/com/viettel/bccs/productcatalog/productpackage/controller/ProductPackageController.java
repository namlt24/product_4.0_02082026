package com.viettel.bccs.productcatalog.productpackage.controller;

import com.viettel.bccs.common.api.response.StandardResponse;
import com.viettel.bccs.common.api.response.StandardResponses;
import com.viettel.bccs.productcatalog.productpackage.dto.response.ProductPackageDTO;
import com.viettel.bccs.productcatalog.productpackage.dto.response.ProductPackageResponse;
import com.viettel.bccs.productcatalog.productpackage.dto.response.SaleServiceAdvanceDTO;
import com.viettel.bccs.productcatalog.productpackage.service.ProductPackageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Product Package", description = "APIs quản lý gói sản phẩm")
@RestController
@RequestMapping("/product-catalog-service/v1/product-package")
@RequiredArgsConstructor
public class ProductPackageController {

    private final ProductPackageService service;

    @GetMapping("/findById/{id}")
    public StandardResponse<ProductPackageResponse> findById(@PathVariable Long id) {
        return StandardResponses.success(service.findById(id));
    }

    @GetMapping("/getByCode/{code}")
    public StandardResponse<List<ProductPackageResponse>> getByCode(@PathVariable String code) {
        return StandardResponses.success(service.findByCode(code));
    }

    @GetMapping("/getByStatus")
    public StandardResponse<List<ProductPackageResponse>> getByStatus(@RequestParam String status) {
        return StandardResponses.success(service.findByStatus(status));
    }

    @GetMapping("/getByType")
    public StandardResponse<List<ProductPackageResponse>> getByType(@RequestParam String type) {
        return StandardResponses.success(service.findByType(type));
    }

    @GetMapping("/getByTelecomServiceId")
    public StandardResponse<List<ProductPackageResponse>> getByTelecomServiceId(@RequestParam Long telecomServiceId) {
        return StandardResponses.success(service.findByTelecomServiceId(telecomServiceId));
    }

    @GetMapping("/getPackageCodesByProductOfferTypeCount")
    public StandardResponse<List<String>> getPackageCodesByProductOfferTypeCount(
            @RequestParam String excludeProdOfferType,
            @RequestParam(required = false) Integer pNumber) {
        return StandardResponses.success(service.findPackageCodesByProductOfferTypeCount(excludeProdOfferType, pNumber));
    }

    @Operation(summary = "Lấy thông tin dịch vụ bán hàng theo mã")
    @GetMapping("/getSaleServicesAdvBOBySSCode")
    public StandardResponse<SaleServiceAdvanceDTO> getSaleServicesAdvBOBySSCode(
            @Parameter(description = "Mã dịch vụ bán hàng") @RequestParam String saleServiceCode) {
        return StandardResponses.success(service.getSaleServicesAdvBOBySSCode(saleServiceCode));
    }
    @Operation(summary = "Lấy thông tin dịch vụ bán lý do")
    @GetMapping("/getSaleServiceInfo")
    public StandardResponse<ProductPackageDTO> getSaleServiceInfo(
            @Parameter(description = "Id lý do") @RequestParam Long reasonId) {
        return StandardResponses.success(service.getSaleServiceInfo(reasonId));
    }
}