package com.viettel.bccs.productcatalog.productpackage.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.viettel.bccs.productcatalog.client.dto.ShopDTO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Schema(description = "Thông tin gói sản phẩm trong offer")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PackageOfferDTO implements Serializable {

    // === ID fields ===
    @Schema(description = "ID offer trong gói")
    @JsonProperty(value = "PROD_PACK_OFFER_ID")
    private Long prodPackOfferId;

    @Schema(description = "ID loại sản phẩm trong gói")
    @JsonProperty(value = "PROD_PACK_TYPE_ID")
    private Long prodPackTypeId;

    @Schema(description = "ID sản phẩm")
    @JsonProperty(value = "PRODUCT_OFFERING_ID")
    private Long productOfferingId;

    @Schema(description = "ID loại sản phẩm")
    @JsonProperty(value = "PRODUCT_OFFER_TYPE_ID")
    private Long productOfferTypeId;

    @Schema(description = "ID gói sản phẩm")
    @JsonProperty(value = "PRODUCT_PACKAGE_ID")
    private Long productPackageId;

    @Schema(description = "ID giá sản phẩm")
    @JsonProperty(value = "PRODUCT_OFFER_PRICE_ID")
    private Long productOfferPriceId;

    // === Basic info ===
    private String offerCode;
    private String offerName;
    private String offerType;
    private String status;
    private String packageCode;
    private String packageName;

    // === Price & stock ===
    private Long price;
    private Long vat;
    private Long numOffer;
    private Long originalPrice;
    private Long minPrice;
    private Long maxPrice;

    private String priceType;
    private String supplyMethod;
    private Long provideMethodId;

    // === SAP & accounting ===
    private Long sapMaterialNumber;
    private String sapMaterialName;
    private String accountingModelCode;
    private String accountingModelName;

    // === Date fields ===
    @Schema(description = "Ngày tạo")
    private Date createDatetime;

    @Schema(description = "Ngày hiệu lực")
    private Date effectDatetime;

    @Schema(description = "Ngày hết hạn")
    private Date expireDatetime;

    @Schema(description = "Ngày cập nhật")
    private Date updateDatetime;

    // === User & version ===
    private String createUser;
    private String updateUser;

    // === Stock checks ===
    private String isMandatory;
    private String checkStaffStock;
    private String checkShopStock;
    private String shopValue;
    private Long updateStockId;
    private String updateStockValue;

    @Builder.Default
    private List<String> updateStockName = new ArrayList<>();

    // === Reason dates ===
    @Schema(description = "Ngày hiệu lực lý do")
    private Date reasonEffectDate;

    @Schema(description = "Ngày hết hạn lý do")
    private Date reasonExpireDate;

    // === Misc ===
    private String newOrSold;
    private String action;
    private String productTypeName;
    private String errorCode;
    private String keyMes;
    private String fakeProdPackTypeId;

    // === Pledge ===
    private String pledgeTime;
    private String pledgeAmount;

    // === Shop list ===
    private String lstShopCode;

    @Builder.Default
    private List<ShopDTO> specShopList = new ArrayList<>();

    // === Limit goods & sale program ===
    private Long limitGoods;
    private Long prodPackTypeLimitGoods;
    private String concatSaleProgram;

    // === Serial ===
    private Short checkSerial;

    // === Description ===
    private String description;
    private String descriptionOffer;

    // === Reason ===
    private String reasonCode;
    private String reasonName;

    // === FTTH display ===
    private String showOrHide;

    // === Distribution ===
    private Long distribute;
    private String distributeName;

    // === Allocation ===
    private String typeAllocation;
    private String numMonthAllocation;

    // === UI state ===
    @Builder.Default
    private boolean selectedRow = false;

    // === Product hierarchy ===
    private String productHierarchy;
}