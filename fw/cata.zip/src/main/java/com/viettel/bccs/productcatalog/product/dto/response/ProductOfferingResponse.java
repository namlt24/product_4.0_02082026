package com.viettel.bccs.productcatalog.product.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

public record ProductOfferingResponse(
    Long productOfferingId,
    Long productSpecId,
    Long productOfferTypeId,
    String name,
    String code,
    String subType,
    Long telecomServiceId,
    String description,
    String status,
    LocalDate effectDatetime,
    LocalDate expireDatetime,
    String createUser,
    LocalDate createDatetime,
    String updateUser,
    LocalDate updateDatetime,
    String version,
    BigDecimal checkSerial,
    BigDecimal checkDeposit,
    String unit,
    String accountingModelCode,
    String accountingModelName,
    String accountingName,
    String accountingCode,
    Long demoDuration,
    BigDecimal isDemo,
    String deviceType,
    BigDecimal transceiver,
    BigDecimal stockModelType,
    Long ownerShopId,
    String returnStockWhenCancelled,
    String returnStockWhenCancelled1,
    BigDecimal sapMaterialNumber,
    String usageId,
    String distribute,
    Long numMonth,
    String isBundle,
    String sapProductType
) {
}