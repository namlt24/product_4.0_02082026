package com.viettel.bccs.productcatalog.productoffercharuse.repository;

import java.util.List;

public interface ProductOfferCharUseRepositoryCustom {

    List<Object[]> findSpecCharsByOfferingIds(List<String> offeringIds);
}