package com.viettel.bccs.organization.custchanneltype.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "CUST_CHANNEL_TYPE_MAPPING")
@Getter
@Setter
public class CustChannelTypeMappingEntity {

    @Id
    @Column(name = "CUST_CHANNEL_TYPE_MAP_ID", nullable = false, precision = 10)
    private Long custChannelTypeMapId;

    @Column(name = "CUST_TYPE", length = 10)
    private String custType;

    @Column(name = "CHANNEL_TYPE_ID", nullable = false, precision = 10)
    private Long channelTypeId;

    @Column(name = "STATUS", nullable = false, length = 1)
    private String status;

    @Column(name = "CREATE_USER", length = 50)
    private String createUser;

    @Column(name = "CREATE_DATETIME")
    private LocalDate createDatetime;

    @Column(name = "UPDATE_USER", length = 50)
    private String updateUser;

    @Column(name = "UPDATE_DATETIME")
    private LocalDate updateDatetime;
}