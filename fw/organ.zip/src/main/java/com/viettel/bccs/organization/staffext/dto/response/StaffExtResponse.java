package com.viettel.bccs.organization.staffext.dto.response;

import java.time.LocalDate;

public record StaffExtResponse(
        Long staffExtId,
        Long staffId,
        String key,
        String value,
        String status,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime
) {
}