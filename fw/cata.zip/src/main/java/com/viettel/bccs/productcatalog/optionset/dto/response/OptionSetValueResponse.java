package com.viettel.bccs.productcatalog.optionset.dto.response;

import java.time.LocalDate;

public record OptionSetValueResponse(
        Long optionSetValueId,
        Long optionSetId,
        String optionSetCode,
        String name,
        String value,
        String status,
        String description,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime,
        Long parentId
) {
}