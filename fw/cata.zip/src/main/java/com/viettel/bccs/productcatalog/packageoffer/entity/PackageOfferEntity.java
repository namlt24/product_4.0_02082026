package com.viettel.bccs.productcatalog.packageoffer.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "PACKAGE_OFFER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PackageOfferEntity {

    @Id
    @Column(name = "PROD_PACK_OFFER_ID", precision = 10)
    private Long prodPackOfferId;

    @Column(name = "PROD_PACK_TYPE_ID", precision = 10)
    private Long prodPackTypeId;

    @Column(name = "PRODUCT_OFFERING_ID", precision = 10)
    private Long productOfferingId;

    @Column(name = "PRODUCT_OFFER_TYPE_ID", precision = 10)
    private Long productOfferTypeId;

    @Column(name = "PRODUCT_PACKAGE_ID", precision = 10)
    private Long productPackageId;

    @Column(name = "PRODUCT_OFFER_PRICE_ID", precision = 10)
    private Long productOfferPriceId;

    @Column(name = "OFFER_CODE", length = 100)
    private String offerCode;

    @Column(name = "OFFER_NAME", length = 500)
    private String offerName;

    @Column(name = "OFFER_TYPE", length = 50)
    private String offerType;

    @Column(name = "STATUS", length = 1)
    private String status;

    @Column(name = "PACKAGE_CODE", length = 100)
    private String packageCode;

    @Column(name = "PACKAGE_NAME", length = 500)
    private String packageName;

    @Column(name = "PRICE", precision = 12)
    private Long price;

    @Column(name = "VAT", precision = 2)
    private Long vat;

    @Column(name = "NUM_OFFER", precision = 5)
    private Long numOffer;

    @Column(name = "ORIGINAL_PRICE", precision = 12)
    private Long originalPrice;

    @Column(name = "MIN_PRICE", precision = 12)
    private Long minPrice;

    @Column(name = "MAX_PRICE", precision = 12)
    private Long maxPrice;

    @Column(name = "PRICE_TYPE", length = 2)
    private String priceType;

    @Column(name = "SUPPLY_METHOD", length = 1)
    private String supplyMethod;

    @Column(name = "PROVIDE_METHOD_ID", precision = 2)
    private Long provideMethodId;

    @Column(name = "SAP_MATERIAL_NUMBER", precision = 10)
    private Long sapMaterialNumber;

    @Column(name = "SAP_MATERIAL_NAME", length = 200)
    private String sapMaterialName;

    @Column(name = "ACCOUNTING_MODEL_CODE", length = 100)
    private String accountingModelCode;

    @Column(name = "ACCOUNTING_MODEL_NAME", length = 200)
    private String accountingModelName;

    @Column(name = "CREATE_DATETIME")
    private Date createDatetime;

    @Column(name = "EFFECT_DATETIME")
    private Date effectDatetime;

    @Column(name = "EXPIRE_DATETIME")
    private Date expireDatetime;

    @Column(name = "UPDATE_DATETIME")
    private Date updateDatetime;

    @Column(name = "CREATE_USER", length = 50)
    private String createUser;

    @Column(name = "UPDATE_USER", length = 50)
    private String updateUser;

    @Column(name = "IS_MANDATORY", length = 1)
    private String isMandatory;

    @Column(name = "CHECK_STAFF_STOCK", length = 1)
    private String checkStaffStock;

    @Column(name = "CHECK_SHOP_STOCK", length = 1)
    private String checkShopStock;

    @Column(name = "SHOP_VALUE", length = 500)
    private String shopValue;

    @Column(name = "UPDATE_STOCK_ID", precision = 10)
    private Long updateStockId;

    @Column(name = "UPDATE_STOCK_VALUE", length = 500)
    private String updateStockValue;

    @Column(name = "REASON_EFFECT_DATE")
    private Date reasonEffectDate;

    @Column(name = "REASON_EXPIRE_DATE")
    private Date reasonExpireDate;

    @Column(name = "NEW_OR_SOLD", length = 1)
    private String newOrSold;

    @Column(name = "ACTION", length = 2)
    private String action;

    @Column(name = "PRODUCT_TYPE_NAME", length = 200)
    private String productTypeName;

    @Column(name = "ERROR_CODE", length = 20)
    private String errorCode;

    @Column(name = "KEY_MES", length = 200)
    private String keyMes;

    @Column(name = "FAKE_PROD_PACK_TYPE_ID", length = 200)
    private String fakeProdPackTypeId;

    @Column(name = "PLEDGE_TIME", length = 50)
    private String pledgeTime;

    @Column(name = "PLEDGE_AMOUNT", length = 50)
    private String pledgeAmount;

    @Column(name = "LST_SHOP_CODE", length = 500)
    private String lstShopCode;

    @Column(name = "LIMIT_GOODS", precision = 10)
    private Long limitGoods;

    @Column(name = "PROD_PACK_TYPE_LIMIT_GOODS", precision = 10)
    private Long prodPackTypeLimitGoods;

    @Column(name = "CONCAT_SALE_PROGRAM", length = 500)
    private String concatSaleProgram;

    @Column(name = "CHECK_SERIAL", precision = 1)
    private Short checkSerial;

    @Column(name = "DESCRIPTION", length = 2000)
    private String description;

    @Column(name = "DESCRIPTION_OFFER", length = 2000)
    private String descriptionOffer;

    @Column(name = "REASON_CODE", length = 20)
    private String reasonCode;

    @Column(name = "REASON_NAME", length = 200)
    private String reasonName;

    @Column(name = "SHOW_OR_HIDE", length = 1)
    private String showOrHide;

    @Column(name = "DISTRIBUTE", precision = 1)
    private Long distribute;

    @Column(name = "DISTRIBUTE_NAME", length = 200)
    private String distributeName;

    @Column(name = "TYPE_ALLOCATION", length = 2)
    private String typeAllocation;

    @Column(name = "NUM_MONTH_ALLOCATION", length = 20)
    private String numMonthAllocation;

    @Transient
    @Column(name = "PRODUCT_HIERARCHY", length = 500)
    private String productHierarchy;
}