package com.viettel.bccs.productcatalog.optionset.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "OPTION_SET_VALUE")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OptionSetValueEntity {

    @Id
    @Column(name = "OPTION_SET_VALUE_ID", precision = 10)
    private Long optionSetValueId;

    @Column(name = "OPTION_SET_ID", precision = 10)
    private Long optionSetId;

    @Column(name = "NAME", length = 512)
    private String name;

    @Column(name = "VALUE", length = 1000)
    private String value;

    @Column(name = "STATUS", length = 1)
    private String status;

    @Column(name = "DESCRIPTION", length = 512)
    private String description;

    @Column(name = "CREATE_USER", length = 50)
    private String createUser;

    @Column(name = "CREATE_DATETIME")
    private LocalDate createDatetime;

    @Column(name = "UPDATE_USER", length = 50)
    private String updateUser;

    @Column(name = "UPDATE_DATETIME")
    private LocalDate updateDatetime;

    @Column(name = "PARENT_ID", precision = 10)
    private Long parentId;
}