package com.viettel.bccs.productcatalog.optionset.controller;

import com.viettel.bccs.common.api.response.StandardResponse;
import com.viettel.bccs.common.api.response.StandardResponses;
import com.viettel.bccs.productcatalog.optionset.dto.response.OptionSetValueResponse;
import com.viettel.bccs.productcatalog.optionset.service.OptionSetValueService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/product-catalog-service/v1/optionsetvalue")
@RequiredArgsConstructor
public class OptionSetValueController {

    private final OptionSetValueService optionSetValueService;

    @GetMapping("/getByOptionSetId")
    public StandardResponse<List<OptionSetValueResponse>> getByOptionSetId(@PathVariable Long optionSetId) {
        return StandardResponses.success(optionSetValueService.getByOptionSetId(optionSetId));
    }

    @GetMapping("/getByOptionSetIdAndStatus")
    public StandardResponse<List<OptionSetValueResponse>> getByOptionSetIdAndStatus(
            @RequestParam Long optionSetId,
            @RequestParam String status) {
        return StandardResponses.success(optionSetValueService.getByOptionSetIdAndStatus(optionSetId, status));
    }

    @GetMapping("/findByOptionSetCode/{code}")
    public StandardResponse<List<OptionSetValueResponse>> findByOptionSetCode(@PathVariable String code) {
        return StandardResponses.success(optionSetValueService.findByOptionSetCode(code));
    }

    @GetMapping("/findByOptionSetCodes")
    public StandardResponse<Map<String, List<OptionSetValueResponse>>> findByOptionSetCodes(
            @RequestParam List<String> codes) {
        return StandardResponses.success(optionSetValueService.findByOptionSetCodes(codes));
    }

    @GetMapping("/getAllGroupCustType")
    @Operation(operationId = "API_PRODUCT_005",
            summary = "API lấy danh sách nhóm loại khách hàng/ loại khách hàng/ loại giấy tờ",
            description = "API lấy danh sách nhóm loại khách hàng/ loại khách hàng/ loại giấy tờ")
    public StandardResponse<List<OptionSetValueResponse>> getAllGroupCustType() {
        return StandardResponses.success(optionSetValueService.getAllGroupCustType());
    }

    @GetMapping("/getValueByTwoCodeOption")
    public StandardResponse<String> getValueByTwoCodeOption(
            @RequestParam String optSetCode,
            @RequestParam String name) {
        return StandardResponses.success(optionSetValueService.getValueByTwoCodeOption(optSetCode, name));
    }
}