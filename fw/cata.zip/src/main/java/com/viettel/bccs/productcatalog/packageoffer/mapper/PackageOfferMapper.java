package com.viettel.bccs.productcatalog.packageoffer.mapper;

import com.viettel.bccs.productcatalog.productpackage.dto.response.PackageOfferDTO;
import com.viettel.bccs.productcatalog.packageoffer.entity.PackageOfferEntity;
import org.springframework.stereotype.Component;

@Component
public class PackageOfferMapper {

    public PackageOfferDTO toDto(PackageOfferEntity entity) {
        if (entity == null) {
            return null;
        }
        return PackageOfferDTO.builder()
                .prodPackOfferId(entity.getProdPackOfferId())
                .prodPackTypeId(entity.getProdPackTypeId())
                .productOfferingId(entity.getProductOfferingId())
                .productOfferTypeId(entity.getProductOfferTypeId())
                .productPackageId(entity.getProductPackageId())
                .productOfferPriceId(entity.getProductOfferPriceId())
                .offerCode(entity.getOfferCode())
                .offerName(entity.getOfferName())
                .offerType(entity.getOfferType())
                .status(entity.getStatus())
                .packageCode(entity.getPackageCode())
                .packageName(entity.getPackageName())
                .price(entity.getPrice())
                .vat(entity.getVat())
                .numOffer(entity.getNumOffer())
                .originalPrice(entity.getOriginalPrice())
                .minPrice(entity.getMinPrice())
                .maxPrice(entity.getMaxPrice())
                .priceType(entity.getPriceType())
                .supplyMethod(entity.getSupplyMethod())
                .provideMethodId(entity.getProvideMethodId())
                .sapMaterialNumber(entity.getSapMaterialNumber())
                .sapMaterialName(entity.getSapMaterialName())
                .accountingModelCode(entity.getAccountingModelCode())
                .accountingModelName(entity.getAccountingModelName())
                .createDatetime(entity.getCreateDatetime())
                .effectDatetime(entity.getEffectDatetime())
                .expireDatetime(entity.getExpireDatetime())
                .updateDatetime(entity.getUpdateDatetime())
                .createUser(entity.getCreateUser())
                .updateUser(entity.getUpdateUser())
                .isMandatory(entity.getIsMandatory())
                .checkStaffStock(entity.getCheckStaffStock())
                .checkShopStock(entity.getCheckShopStock())
                .shopValue(entity.getShopValue())
                .updateStockId(entity.getUpdateStockId())
                .updateStockValue(entity.getUpdateStockValue())
                .reasonEffectDate(entity.getReasonEffectDate())
                .reasonExpireDate(entity.getReasonExpireDate())
                .newOrSold(entity.getNewOrSold())
                .action(entity.getAction())
                .productTypeName(entity.getProductTypeName())
                .errorCode(entity.getErrorCode())
                .keyMes(entity.getKeyMes())
                .fakeProdPackTypeId(entity.getFakeProdPackTypeId())
                .pledgeTime(entity.getPledgeTime())
                .pledgeAmount(entity.getPledgeAmount())
                .lstShopCode(entity.getLstShopCode())
                .limitGoods(entity.getLimitGoods())
                .prodPackTypeLimitGoods(entity.getProdPackTypeLimitGoods())
                .concatSaleProgram(entity.getConcatSaleProgram())
                .checkSerial(entity.getCheckSerial())
                .description(entity.getDescription())
                .descriptionOffer(entity.getDescriptionOffer())
                .reasonCode(entity.getReasonCode())
                .reasonName(entity.getReasonName())
                .showOrHide(entity.getShowOrHide())
                .distribute(entity.getDistribute())
                .distributeName(entity.getDistributeName())
                .typeAllocation(entity.getTypeAllocation())
                .numMonthAllocation(entity.getNumMonthAllocation())
                .productHierarchy(entity.getProductHierarchy())
                .build();
    }
}