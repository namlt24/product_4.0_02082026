package com.viettel.bccs.productcatalog.productofferrelationdetail.dto.response;

import java.time.LocalDate;

public record ProductOfferRelationDetailResponse(
        Long productOfferRelationDetail,
        Long productOfferRelationId,
        Long productSpecCharId,
        Long productSpecCharValueId,
        String status,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime,
        String specificValue,
        String description,
        LocalDate effectDatetime,
        LocalDate expireDatetime
) {
}