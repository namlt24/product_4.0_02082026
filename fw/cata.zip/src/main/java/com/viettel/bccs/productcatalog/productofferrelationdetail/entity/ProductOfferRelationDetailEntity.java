package com.viettel.bccs.productcatalog.productofferrelationdetail.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "PRODUCT_OFFER_RELATION_DETAIL")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductOfferRelationDetailEntity {

    @Id
    @Column(name = "PRODUCT_OFFER_RELATION_DETAIL", precision = 38)
    private Long productOfferRelationDetail;

    @Column(name = "PRODUCT_OFFER_RELATION_ID", precision = 10)
    private Long productOfferRelationId;

    @Column(name = "PRODUCT_SPEC_CHAR_ID", precision = 10)
    private Long productSpecCharId;

    @Column(name = "PRODUCT_SPEC_CHAR_VALUE_ID", precision = 10)
    private Long productSpecCharValueId;

    @Column(name = "STATUS", length = 1)
    private String status;

    @Column(name = "CREATE_USER", length = 50)
    private String createUser;

    @Column(name = "CREATE_DATETIME")
    private LocalDate createDatetime;

    @Column(name = "UPDATE_USER", length = 50)
    private String updateUser;

    @Column(name = "UPDATE_DATETIME")
    private LocalDate updateDatetime;

    @Column(name = "SPECIFIC_VALUE", length = 50)
    private String specificValue;

    @Column(name = "DESCRIPTION", length = 512)
    private String description;

    @Column(name = "EFFECT_DATETIME")
    private LocalDate effectDatetime;

    @Column(name = "EXPIRE_DATETIME")
    private LocalDate expireDatetime;
}