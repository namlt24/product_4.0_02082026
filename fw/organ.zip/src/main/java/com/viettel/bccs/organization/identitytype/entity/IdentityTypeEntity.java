package com.viettel.bccs.organization.identitytype.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "IDENTITY_TYPE")
@Getter
@Setter
public class IdentityTypeEntity {

    @Id
    @Column(name = "ID_TYPE", nullable = false, length = 10)
    private String idType;

    @Column(name = "NAME", nullable = false, length = 100)
    private String name;

    @Column(name = "CREATE_USER", nullable = false, length = 50)
    private String createUser;

    @Column(name = "CREATE_DATETIME", nullable = false)
    private LocalDate createDatetime;

    @Column(name = "UPDATE_USER", length = 50)
    private String updateUser;

    @Column(name = "UPDATE_DATETIME")
    private LocalDate updateDatetime;

    @Column(name = "DESCRIPTION", length = 512)
    private String description;

    @Column(name = "STATUS", nullable = false, length = 1)
    private String status;

    @Column(name = "MIN_LENGTH", precision = 3)
    private Integer minLength;

    @Column(name = "MAX_LENGTH", precision = 3)
    private Integer maxLength;

    @Column(name = "VALUE_PATTERN", length = 100)
    private String valuePattern;
}