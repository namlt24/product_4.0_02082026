package com.viettel.bccs.productcatalog.optionset.service;

import com.viettel.bccs.productcatalog.optionset.dto.response.OptionSetValueResponse;
import com.viettel.bccs.productcatalog.optionset.entity.OptionSetValueEntity;
import com.viettel.bccs.productcatalog.optionset.mapper.OptionSetValueMapper;
import com.viettel.bccs.productcatalog.optionset.repository.OptionSetValueRepository;
import com.viettel.bccs.productcatalog.utils.Const;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class OptionSetValueService {

    private final OptionSetValueRepository optionSetValueRepository;
    private final OptionSetValueMapper optionSetValueMapper;

    @Transactional(readOnly = true)
    public List<OptionSetValueResponse> getByOptionSetId(Long optionSetId) {
        return optionSetValueRepository.findByOptionSetId(optionSetId).stream()
                .map(optionSetValueMapper::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<OptionSetValueResponse> getByOptionSetIdAndStatus(Long optionSetId, String status) {
        return optionSetValueRepository.findByOptionSetIdAndStatus(optionSetId, status).stream()
                .map(optionSetValueMapper::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<OptionSetValueResponse> findByOptionSetCode(String code) {
        return optionSetValueRepository.findByOptionSetCode(code).stream()
                .map(optionSetValueMapper::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public Map<String, List<OptionSetValueResponse>> findByOptionSetCodes(List<String> codes) {
        List<Object[]> rows = optionSetValueRepository.findByOptionSetCodes(codes);
        return rows.stream()
                .map(row -> optionSetValueMapper.toResponse(
                        buildEntityFromRow(row),
                        row[11] != null ? row[11].toString().trim() : null))
                .toList()
                .stream()
                .collect(java.util.stream.Collectors.groupingBy(OptionSetValueResponse::optionSetCode));
    }

    private OptionSetValueEntity buildEntityFromRow(Object[] row) {
        return OptionSetValueEntity.builder()
                .optionSetValueId(row[0] != null ? ((Number) row[0]).longValue() : null)
                .optionSetId(row[1] != null ? ((Number) row[1]).longValue() : null)
                .name(row[2] != null ? row[2].toString() : null)
                .value(row[3] != null ? row[3].toString() : null)
                .status(row[4] != null ? row[4].toString() : null)
                .description(row[5] != null ? row[5].toString() : null)
                .createUser(row[6] != null ? row[6].toString() : null)
                .createDatetime(row[7] instanceof java.sql.Date d ? d.toLocalDate() : null)
                .updateUser(row[8] != null ? row[8].toString() : null)
                .updateDatetime(row[9] instanceof java.sql.Date d ? d.toLocalDate() : null)
                .parentId(row[10] != null ? ((Number) row[10]).longValue() : null)
                .build();
    }

    @Transactional(readOnly = true)
    public List<OptionSetValueResponse> getAllGroupCustType() {
        String custTypeGroupType = Const.OPTION_SET.CUST_TYPE_GROUP_TYPE;
        return optionSetValueRepository.findByOptionSetCode(custTypeGroupType).stream()
                .map(optionSetValueMapper::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public String getValueByTwoCodeOption(String optSetCode, String code) {
        return optionSetValueRepository.findValueByTwoCodeOption(optSetCode, code);
    }
}