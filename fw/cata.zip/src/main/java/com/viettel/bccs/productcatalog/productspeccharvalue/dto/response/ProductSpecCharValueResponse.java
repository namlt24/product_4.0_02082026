package com.viettel.bccs.productcatalog.productspeccharvalue.dto.response;

import java.time.LocalDate;

public record ProductSpecCharValueResponse(
        Long productSpecCharValueId,
        Long productSpecCharId,
        String valueType,
        Long isDefault,
        String value,
        String unitOfMeasure,
        String valueFrom,
        String valueTo,
        String rangeInterval,
        String status,
        String createUser,
        LocalDate createDatetime,
        String updateUser,
        LocalDate updateDatetime,
        String name,
        String specificValue,
        String note
) {
}