package com.viettel.bccs.productcatalog.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Yêu cầu lọc theo đặc tính sản phẩm")
public class FilterRequest implements Serializable {

    public enum Operator {
        IN,
        EQ,
        NE,
        NOTIN,
        LT,
        GT,
        LOE,
        GOE,
        BETWEEN,
        LIKE,
        EXACT,
        LIKE_BEGIN,
        LIKE_END,
        RANGE,
        STARTWITH,
        IS_NULL,
        IS_NOT_NULL
    }

    @Schema(description = "Mã thuộc tính đặc tính (code của product_spec_char)", example = "SPEED")
    private String property;

    @Schema(description = "Giá trị so sánh dạng text", example = "100")
    private String valueText;

    @Schema(description = "Kiểu giá trị: LONG, STRING, DATE...", example = "LONG")
    private String valueType;

    @Schema(description = "Toán tử so sánh: EQ, NE, LT, GT, LOE, GOE, BETWEEN, LIKE...", example = "EQ")
    private Operator operator;

    @Schema(description = "True: dùng NOT EXISTS (loại trừ), False: dùng EXISTS (lọc theo)", example = "false")
    private boolean notEqual;
}